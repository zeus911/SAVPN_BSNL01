
/*
 ***************************************************************************
 *
 * (c) Copyright 2003-2010 Hewlett-Packard Development Company, L.P. 
 *
 ************************************************************************
 */

package com.hp.ov.activator.crmportal.helpers; 

import org.apache.log4j.Logger;
import org.apache.xerces.parsers.DOMParser;
//import org.apache.xpath.XPathAPI;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import javax.servlet.http.HttpSession;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import java.util.*;
import java.io.*;
import com.hp.ov.activator.crmportal.common.*;
import com.hp.ov.activator.crmportal.utils.Constants;

//import com.sun.org.apache.xpath.internal.XPathAPI;


/**
 * Takes xml file and generates list of users and roles assigned to them
 * Format of the xml file is:
 * <pre>
 * <Users>
 * <User name="admin" roles="admin,operator,observer"/>
 * <User name="operator" roles="operator"/>
 * <User name="visitor" roles="observer"/>
 * <Default-roles>observer</Default-roles>
 * </Users>
 * </pre>
 */

public class BasicAuthenticator
{
	
	private String path;
	private HashMap users = new HashMap();
	private HashSet defaultRole;


	/**
	 * The only constructor. Validates if the path is correct
	 * and file exists
	 */
	public BasicAuthenticator(String path) throws FileNotFoundException 
	{
	    final File file = new File(path);
		if (!file.exists())
			throw new FileNotFoundException(path);
		this.path = path;
	}

	/**
	 * Initializes roles using xml file and checks if user exists in the
	 * users list.
	 * If exists then its roles are saved into the session
	 * @param session The session where roles are saved in the case of success
	 * @param login Username to be checked
	 * @return True if user was authorized, false if not
	 */
	public boolean authorize(HttpSession session, String login,
			                 String password)
	{
	   HashSet roles;
	   boolean loginAuthorized = false;
	    try 
	    {
		initialize();
	    } catch (Exception e) {
		e.printStackTrace();
		return false;
	    }
	    
	    synchronized (this) 
	    {
		roles = (HashSet) users.get(String.valueOf(login));
	
           if(roles != null)
			{
               loginAuthorized = true;
			}
		   
		   if ((roles == null) && (defaultRole != null))
		   {		   
			 roles = defaultRole;
			 loginAuthorized = true;
		   }

		   if ((roles == null) && (defaultRole == null))
		   {		   
			loginAuthorized = false;
		   }

	    }//end of synchronized block

	    session.setAttribute(Constants.ROLES_KEY, roles);   
	    return loginAuthorized;
	}

	/**
	 * Searches a role in the session object and returns result of the search
	 * @param session HttpSession where user roles are saved
	 * @param role A role that is attempted to find in the session object
	 * @return true if role is found, otherwise false
	 */
	public boolean isUserInRole(HttpSession session, String role)
	{
	    try 
	    {
		final HashSet roles = (HashSet) session.getAttribute(Constants.ROLES_KEY);
		return roles.contains(role);
	    } catch (Exception ex) {
		return false;
	    }
	}

	

	/**
	 * Reads xml file, parses it and generates structures with usernames
	 * and roles
	 * @throws IOException File reading problems
	 * @throws TransformerException XPath is wrong generated
	 * @throws SAXException Parsing problems
	 */
	private void initialize() throws IOException, TransformerException,
	SAXException, XPathExpressionException {
	    synchronized (this) 
	    {
		final HashMap tempMap = new HashMap(users.size());
		final DOMParser parser = new DOMParser();
		final Reader in = new BufferedReader(new FileReader(new File(path)));
		final InputSource input = new org.xml.sax.InputSource(in);

		parser.parse(input);

		final Document document = parser.getDocument();
		XPathFactory factory = XPathFactory.newInstance();
	    XPath xPath = factory.newXPath();
		//final NodeList users = XPathAPI.selectNodeList(document, "Users/User");
		final NodeList users = (NodeList)xPath.evaluate("Users/User", document, XPathConstants.NODESET);
		//final NodeList defautRolesNode = XPathAPI.selectNodeList(document, "Users/Default-roles");	
		final NodeList defautRolesNode = (NodeList)xPath.evaluate("Users/Default-roles", document, XPathConstants.NODESET);
		 String defaultRoles = defautRolesNode.getLength() > 0 ? defautRolesNode.item(0).getFirstChild().getNodeValue() : null;
           

		for (int i = 0; i < users.getLength(); i++) 
		{
		    final String name = users.item(i).getAttributes().getNamedItem("name").getNodeValue();
		    final String roles = users.item(i).getAttributes().getNamedItem("roles").getNodeValue();
		    tempMap.put(name, parseList(roles));
		}

         if(defaultRoles!=null)
			 {
		  this.defaultRole = parseList(defaultRoles); 
		     }
		
		if(defaultRoles==null)
			{
          this.defaultRole = null ;
			 }
		this.users = tempMap;
	    }
	}
	
	/**
	 * Transforms comma-separated list into java.util.HashSet
	 * @param rolesList comma-separated list
	 * @return Set of the elements
	 */
	private static HashSet parseList(String rolesList) 
	{
		final HashSet result = new HashSet();
		final StringTokenizer tokenizer = new StringTokenizer(rolesList, ",");
	   
		if (rolesList == null || rolesList.trim().equals(""))
		return null;
	     
	    while (tokenizer.hasMoreTokens()) 
	    {
		result.add(tokenizer.nextToken().trim());
	    }
	    return result;
	}
	
	
	
}


